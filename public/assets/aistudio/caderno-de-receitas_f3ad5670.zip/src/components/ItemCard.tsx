import { Link } from "react-router-dom";
import { Clock, Lock } from "lucide-react";
import type { CatalogItem } from "@/lib/types";
import { CATEGORY_LABEL } from "@/lib/types";

export function ItemCard({ item, locked }: { item: CatalogItem; locked: boolean }) {
  return (
    <Link
      to={locked ? "/planos" : `/item/${item.id}`}
      state={locked ? { message: "Esse conteúdo é para assinantes Premium." } : undefined}
      className="card flex h-full flex-col gap-2 transition-shadow hover:shadow-md"
    >
      <span className="text-xs font-semibold uppercase tracking-wide text-terracotta-dark">
        {CATEGORY_LABEL[item.category]}
      </span>
      <h3 className="text-lg font-bold leading-snug">{item.title}</h3>
      <div className="mt-auto flex flex-wrap items-center gap-3 text-sm text-muted">
        {item.level && <span>{item.level}</span>}
        {item.time && (
          <span className="inline-flex items-center gap-1"><Clock size={14} aria-hidden /> {item.time}</span>
        )}
        {locked && (
          <span className="ml-auto inline-flex items-center gap-1 font-medium text-terracotta-dark">
            <Lock size={14} aria-hidden /> Premium
          </span>
        )}
      </div>
    </Link>
  );
}
