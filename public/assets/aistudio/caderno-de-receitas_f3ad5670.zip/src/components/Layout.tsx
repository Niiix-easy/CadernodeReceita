import { Link, NavLink, Outlet } from "react-router-dom";
import { BookOpen, Heart, LogOut, Crown } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useSubscription } from "@/context/SubscriptionContext";

const nav = "flex min-h-[44px] items-center gap-1.5 rounded-lg px-3 text-sm font-medium hover:bg-sand";
const active = "bg-sand text-terracotta-dark";

export function Layout() {
  const { user, signOut } = useAuth();
  const { isPremium } = useSubscription();
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b border-ink/10 bg-cream/95 backdrop-blur">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-2 px-4 py-2">
          <Link to="/" className="flex items-center gap-2 font-display text-lg font-bold text-terracotta-dark">
            <BookOpen size={22} aria-hidden /> Caderno de Receitas
          </Link>
          <nav aria-label="Principal" className="flex flex-wrap items-center gap-1">
            <NavLink to="/" end className={({ isActive }) => `${nav} ${isActive ? active : ""}`}>Início</NavLink>
            <NavLink to="/favoritos" className={({ isActive }) => `${nav} ${isActive ? active : ""}`}>
              <Heart size={16} aria-hidden /> Favoritos
            </NavLink>
            <NavLink to="/assinatura" className={({ isActive }) => `${nav} ${isActive ? active : ""}`}>
              <Crown size={16} aria-hidden /> {isPremium ? "Premium" : "Assinar"}
            </NavLink>
            <button type="button" onClick={() => void signOut()} className={nav} title={user?.email ?? ""}>
              <LogOut size={16} aria-hidden /> Sair
            </button>
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-6">
        <Outlet />
      </main>
      <footer className="border-t border-ink/10 px-4 py-4 text-center text-xs text-muted">
        Receitas e dicas reunidas de fontes públicas; sempre confira a fonte original.
      </footer>
    </div>
  );
}
