import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Search } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { CATEGORY_LABEL, type CatalogItem, type Category } from "@/lib/types";
import { ItemCard } from "@/components/ItemCard";
import { Spinner } from "@/components/Spinner";
import { useSubscription } from "@/context/SubscriptionContext";

const TABS: Category[] = ["food", "health", "soap"];

export default function Home() {
  const { isPremium } = useSubscription();
  const [items, setItems] = useState<CatalogItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<Category>("food");
  const [q, setQ] = useState("");

  useEffect(() => {
    let alive = true;
    supabase.from("items_catalog").select("id,category,title,level,time").order("id").then(({ data, error: e }) => {
      if (!alive) return;
      if (e) setError("Não foi possível carregar o catálogo. Tente novamente.");
      else setItems((data ?? []) as CatalogItem[]);
      setLoading(false);
    });
    return () => { alive = false; };
  }, []);

  const visible = useMemo(() => {
    const term = q.trim().toLowerCase();
    return items.filter((i) => i.category === tab && (!term || i.title.toLowerCase().includes(term)));
  }, [items, tab, q]);

  return (
    <div className="space-y-5">
      {!isPremium && (
        <div className="card flex flex-wrap items-center justify-between gap-3 border-terracotta/30 bg-sand">
          <p className="text-sm">Você está no plano Grátis: vê o catálogo. Assine o Premium para abrir receitas, vídeos e favoritos.</p>
          <Link to="/planos" className="btn-primary">Ver planos</Link>
        </div>
      )}

      {tab === "health" && (
        <p role="note" className="rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
          Conteúdo informativo; não substitui orientação médica.
        </p>
      )}

      <div role="tablist" aria-label="Categorias" className="flex flex-wrap gap-2">
        {TABS.map((c) => (
          <button key={c} role="tab" aria-selected={tab === c} onClick={() => setTab(c)}
            className={`btn ${tab === c ? "bg-terracotta text-white" : "border border-ink/15 bg-white hover:bg-sand"}`}>
            {CATEGORY_LABEL[c]}
          </button>
        ))}
      </div>

      <div className="relative">
        <label htmlFor="busca" className="sr-only">Buscar por título</label>
        <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" size={18} aria-hidden />
        <input id="busca" type="search" className="input pl-10" placeholder="Buscar por título" value={q}
          onChange={(e) => setQ(e.target.value)} />
      </div>

      {loading ? <Spinner /> : error ? (
        <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-800">{error}</p>
      ) : visible.length === 0 ? (
        <div className="card text-center">
          <p className="font-medium">Nada encontrado para “{q}”.</p>
          <button className="btn-secondary mt-3" onClick={() => setQ("")}>Limpar busca</button>
        </div>
      ) : (
        <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {visible.map((i) => <li key={i.id}><ItemCard item={i} locked={!isPremium} /></li>)}
        </ul>
      )}
    </div>
  );
}
