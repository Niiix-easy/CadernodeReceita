import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, ExternalLink, Heart, TriangleAlert } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { CATEGORY_LABEL, SAFETY_TEXT, type Item } from "@/lib/types";
import { useAuth } from "@/context/AuthContext";
import { Spinner } from "@/components/Spinner";

export default function ItemDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [item, setItem] = useState<Item | null>(null);
  const [loading, setLoading] = useState(true);
  const [fav, setFav] = useState(false);
  const [favBusy, setFavBusy] = useState(false);
  const [ack, setAck] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    setLoading(true); setAck(false);
    (async () => {
      const { data, error: e } = await supabase.from("items").select("*").eq("id", id ?? "").maybeSingle();
      if (!alive) return;
      if (e) setError("Não foi possível carregar este item.");
      setItem((data as Item | null) ?? null);
      if (user && data) {
        const f = await supabase.from("favorites").select("item_id").eq("user_id", user.id).eq("item_id", id ?? "").maybeSingle();
        if (alive) setFav(Boolean(f.data));
      }
      if (alive) setLoading(false);
    })();
    return () => { alive = false; };
  }, [id, user]);

  async function toggleFav() {
    if (!user || !item) return;
    setFavBusy(true);
    const { error: e } = fav
      ? await supabase.from("favorites").delete().eq("user_id", user.id).eq("item_id", item.id)
      : await supabase.from("favorites").insert({ user_id: user.id, item_id: item.id });
    setFavBusy(false);
    if (e) setError("Não foi possível atualizar os favoritos."); else { setFav(!fav); setError(null); }
  }

  if (loading) return <Spinner />;
  if (!item) {
    return (
      <div className="card text-center">
        <p className="font-medium">{error ?? "Item não encontrado."}</p>
        <Link to="/" className="btn-secondary mt-3">Voltar ao início</Link>
      </div>
    );
  }

  const needsAck = item.safety && !ack;

  return (
    <article className="space-y-6">
      <Link to="/" className="inline-flex min-h-[44px] items-center gap-1 text-sm text-terracotta-dark"><ArrowLeft size={16} aria-hidden /> Voltar</Link>

      <header className="space-y-2">
        <p className="text-xs font-semibold uppercase tracking-wide text-terracotta-dark">{CATEGORY_LABEL[item.category]}</p>
        <div className="flex items-start justify-between gap-3">
          <h1 className="text-3xl font-bold">{item.title}</h1>
          <button onClick={toggleFav} disabled={favBusy} aria-pressed={fav}
            aria-label={fav ? "Remover dos favoritos" : "Adicionar aos favoritos"} className="btn-secondary shrink-0">
            <Heart size={18} aria-hidden className={fav ? "fill-terracotta text-terracotta" : ""} />
          </button>
        </div>
        <p className="text-sm text-muted">{[item.level, item.time, item.servings].filter(Boolean).join(" · ")}</p>
        {item.summary && <p>{item.summary}</p>}
        {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
      </header>

      {item.category === "health" && (
        <p role="note" className="rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
          Conteúdo informativo; não substitui orientação médica.
        </p>
      )}

      {item.safety && (
        <section aria-labelledby="seg" className="rounded-xl border-2 border-red-700 bg-red-50 p-4 text-red-900">
          <h2 id="seg" className="mb-2 flex items-center gap-2 text-lg font-bold"><TriangleAlert size={20} aria-hidden /> ⚠️ AVISOS DE SEGURANÇA — soda cáustica</h2>
          <p className="text-sm">{SAFETY_TEXT}</p>
          <label className="mt-3 flex min-h-[44px] items-center gap-2 text-sm font-semibold">
            <input type="checkbox" className="h-5 w-5" checked={ack} onChange={(e) => setAck(e.target.checked)} />
            Li e entendi
          </label>
        </section>
      )}

      {item.video_id ? (
        <div className="aspect-video w-full overflow-hidden rounded-2xl bg-black">
          <iframe className="h-full w-full" src={`https://www.youtube-nocookie.com/embed/${encodeURIComponent(item.video_id)}`}
            title={`Vídeo: ${item.title}`} loading="lazy" allowFullScreen referrerPolicy="strict-origin-when-cross-origin"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" />
        </div>
      ) : item.channel_url ? (
        <a href={item.channel_url} target="_blank" rel="noopener noreferrer" className="btn-secondary">
          Ver canal oficial no YouTube <ExternalLink size={16} aria-hidden />
        </a>
      ) : null}
      {item.note && <p className="text-sm text-muted">Obs.: {item.note}</p>}

      {item.ingredients.length > 0 && (
        <section aria-labelledby="ing">
          <h2 id="ing" className="mb-2 text-xl font-bold">Ingredientes</h2>
          <ul className="list-disc space-y-1 pl-5">{item.ingredients.map((x, i) => <li key={i}>{x}</li>)}</ul>
        </section>
      )}

      <section aria-labelledby="pas">
        <h2 id="pas" className="mb-2 text-xl font-bold">{item.category === "health" ? "O que fazer" : "Modo de preparo"}</h2>
        {needsAck ? (
          <p className="rounded-lg bg-sand p-3 text-sm">Marque “Li e entendi” nos avisos de segurança para ver os passos.</p>
        ) : (
          <ol className="list-decimal space-y-2 pl-5">{item.steps.map((x, i) => <li key={i}>{x}</li>)}</ol>
        )}
      </section>

      {item.source_url && (
        <a href={item.source_url} target="_blank" rel="noopener noreferrer" className="btn-secondary">
          Ver fonte original <ExternalLink size={16} aria-hidden />
        </a>
      )}
    </article>
  );
}
